package io.deanencoded.twedit.items

class Tweet(val tweetId: Int, val tweetBy: Int,val name: String,val username: String,val text: String,val time: Int,val edited: Boolean)